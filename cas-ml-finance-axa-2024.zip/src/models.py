# TODO: Replace with public OpenAI models
import os

from genai_core_langchain_addons.genai_core_azure_openai import GenAICoreAzureChatOpenAI, GenAICoreAzureOpenAIEmbeddings

os.environ["http_proxy"] = "127.0.0.1:8887"
os.environ["https_proxy"] = "127.0.0.1:8887"

gpt35 = GenAICoreAzureChatOpenAI(
    project="axach-as-doc-ai-cch-exp",
    llm_gw_api_key=os.environ["LLM_GW_API_KEY"],
    esg_consumer_cert_path=None,
    model="gpt-35-turbo",
    deployment_name="gpt-35-turbo",
    openai_api_version="2023-05-15",
)

gpt4 = GenAICoreAzureChatOpenAI(
    project="axach-as-doc-ai-cch-exp",
    llm_gw_api_key=os.environ["LLM_GW_API_KEY"],
    esg_consumer_cert_path=None,
    model="gpt-4-32k",
    deployment_name="gpt-4-32k",
    openai_api_version="2023-05-15",
)

embedding_model = GenAICoreAzureOpenAIEmbeddings(
    llm_gw_api_key=os.environ["LLM_GW_API_KEY"],
    deployment="text-embedding-ada-002",
    openai_api_version="2023-05-15",
    model="text-embedding-ada-002",
    chunk_size=16,
    project="axach-as-doc-ai-cch-exp",
)
